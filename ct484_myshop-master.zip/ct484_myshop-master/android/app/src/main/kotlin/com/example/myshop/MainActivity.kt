package com.example.myshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
